# Implementation-of-ML-in-Health-Care-5-projects

This is one of the major project of my 2nd year .

Here, I have developed a disease predicting web app which using the concept of machine learning makes predictions about various diseases like cancer,heart, Diabetes etc.

#Tools used for project development:

* Python ( 3.8 version)

* Streamlit

* Pandas

* Numpy

* Scikit-Learn

* Pickle


The whole project is deployed on Heroku Cloud.

Here is the link where you can access the project live : 	 
	https://healthcare-app-prediction.herokuapp.com/
	


Thank you!



Reference - The reference for all the medical terms and images are taken from youtuber (Krish naik)..


